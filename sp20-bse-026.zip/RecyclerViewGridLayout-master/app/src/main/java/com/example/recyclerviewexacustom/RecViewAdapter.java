package com.example.recyclerviewexacustom;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class RecViewAdapter extends RecyclerView.Adapter<RecViewAdapter.RecViewViewHoder> {
    private int[] resids;
    public RecViewAdapter(int[] values) {
        this.resids = values;
    }

    @NonNull
    @Override
    public RecViewViewHoder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //Creating the layout for the single item of recyclerview
        LinearLayout itemLayout =(LinearLayout) LayoutInflater.from(parent.getContext()).inflate(R.layout.recview_item_grid,parent,false);
        RecViewViewHoder recViewViewHoder = new RecViewViewHoder(itemLayout);
        return recViewViewHoder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecViewViewHoder holder, int position) {
        holder.imageView.setImageResource(resids[position]);
    }

    @Override
    public int getItemCount() {
        return resids.length*3;
    }

    public class RecViewViewHoder extends RecyclerView.ViewHolder {
        ImageView imageView;
        public RecViewViewHoder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(itemView.getContext(), "You pressed an image", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
