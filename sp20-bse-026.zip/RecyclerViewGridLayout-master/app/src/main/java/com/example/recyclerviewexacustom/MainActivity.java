package com.example.recyclerviewexacustom;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recViewM);
        //first step
        recyclerView.setLayoutManager(new GridLayoutManager(this,3));
        //optional
        recyclerView.setHasFixedSize(true);
    }

    @Override
    protected void onStart() {
        super.onStart();
        //Data
        int[] resids = new int[7];
        resids[0] = R.raw.avengers_30;
        resids[1] = R.raw.dare_devil_30;
        resids[2] = R.raw.fantastic_four_30;
        resids[3] = R.raw.green_lantern_30;
        resids[4] = R.raw.spider_man_30;
        resids[5] = R.raw.superman_30;
        resids[6] = R.raw.the_flash_30;
        RecViewAdapter recViewAdapter = new RecViewAdapter(resids);
        recyclerView.setAdapter(recViewAdapter);
    }
}